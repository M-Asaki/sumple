class PagesController < ApplicationController
  def index
  end

  def help
  end
end
